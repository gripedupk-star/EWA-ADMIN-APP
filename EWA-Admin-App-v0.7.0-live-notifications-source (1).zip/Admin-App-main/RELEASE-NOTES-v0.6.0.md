# EWA Admin Android v0.6.0

Updated against EWA Core v4.3.3.

## Changes
- Orders now show customer contact, City, Delivery Address, quantity, amount, status and created time.
- Membership status displays ACTIVE as APPROVED for the teacher while preserving the server's ACTIVE API contract.
- Courses now display all assigned classes from `class_names` (multi-class architecture).
- Added Video Sessions to mobile navigation.
- Video Sessions show student, father, class, city, mobile, WhatsApp, requested slot, fee, payment screenshot and status.
- Pending video sessions can be Confirmed with date/time or Rejected with a reason.
- App version bumped to 0.6.0 / versionCode 12.
- Existing authentication, students, memberships, payment settings, analytics, notifications and WhatsApp queue are preserved.
